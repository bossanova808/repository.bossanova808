Uses data provided by the BOM (via Weatherzone).


