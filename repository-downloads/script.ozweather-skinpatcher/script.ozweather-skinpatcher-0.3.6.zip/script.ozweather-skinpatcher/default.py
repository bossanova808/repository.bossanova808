# -*- coding: utf-8 -*-

from resources.lib import ozweather_skinpatcher

if __name__ == "__main__":
    ozweather_skinpatcher.run()
