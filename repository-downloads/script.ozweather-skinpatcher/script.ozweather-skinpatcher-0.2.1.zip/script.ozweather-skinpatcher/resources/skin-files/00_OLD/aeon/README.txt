This Kodi MyWeather.xml mod integrates bossanova808's OzWeather addon radar capabilities into the Aeon Nox Silvo skin.

Use this MyWeather.xml to replace the MyWeather.xml file in:

Windows: 
C:\Users\{username}\AppData\Roaming\Kodi\addons\skin.aeon.nox.silvo\16x9\

*nix
~/.kodi/addons/skin.aeon.nox.silvo/16x9/

Android:
I have no idea. Wherever skin addons go.

In order to make the Fire Warning graphic work, place the "firedanger" folder in the following:

Windows:
C:\Users\{username}\AppData\Roaming\Kodi\userdata\addon_data\weather.ozweather\

*nix
~/.kodi/userdata/addon_data/weather.ozweather/

The "firedanger" folder should end up next to the "radarbackgrounds" folder.
