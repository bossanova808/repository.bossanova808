
Kodi OzWeather Skin Patcher
===================================

_script.ozweather-skinpatcher_

Utility to make patching of skin files for [OzWeather](https://kodi.wiki/view/Add-on:Oz_Weather) radar support more simple.

If a skin update comes along and breaks your radar support, then just (re-)run this add-on, and it will patch the skin files for you.  

Note - will only patch files for the currently active skin.
Note - will only patch skin files for supported skins - Estuary, Estouchy, Confluence, Xonfluence, Amber, Aeon (Nox Silvo and Tajo).

(Patch files to support other skins, and a matching pull requests here, very gratefully accepted!).





