# skin.confluence

Essentially, this is a bossanova808 specific fork of Confluence with a few me-useful things added.

(The weather section has been replaced with OzWeather skin files so this will not be useful to people outside of Australia).
