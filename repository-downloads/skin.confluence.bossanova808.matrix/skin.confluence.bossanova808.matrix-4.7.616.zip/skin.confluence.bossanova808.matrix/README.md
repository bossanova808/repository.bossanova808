# skin.confluence
Private fork of Confluence with a few useful things added.  This is just a holding repo for updates - skin is actually distributed from repository.bossanova808
