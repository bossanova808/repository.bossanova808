
# How to Update

(Feb 2019 - Currently set up only at home)

The basic  appraoch is to:

- (https://help.github.com/articles/syncing-a-fork/)
- fetch upstream changes
- merge these in
- commit to my Confluence repo
- Copy to repository.bossnova808/staging area
- Update addon.xml to add version digits(2) to end of upstream version 
  e.g. 4.5.1501
- Run addons_xml_generator.py & copy over zip as usual
- Commit & test









