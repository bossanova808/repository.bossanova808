from bossanova808 import exception_logger
from resources.lib import context_menu

if __name__ == "__main__":
    with exception_logger.log_exception():
        context_menu.run_series()
