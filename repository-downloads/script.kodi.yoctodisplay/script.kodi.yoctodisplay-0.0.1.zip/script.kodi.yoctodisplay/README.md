Kodi YoctoDisplay Addon
==========================

Copyright (C) 2016 bossanova808

Display media and now playing information on USB driven Yoctopuce MaxiDisplay OLED displays.

This program is NOT free software.  You may not modify or distrubute it in any way without permission - contact bossanova808@gmail.com

