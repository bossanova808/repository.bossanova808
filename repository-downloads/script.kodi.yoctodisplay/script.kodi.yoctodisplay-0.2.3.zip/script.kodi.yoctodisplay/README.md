Kodi YoctoDisplay Addon
==========================

`script.kodi.yoctodisplay`

Display media and now playing information on USB driven Yoctopuce MaxiDisplay OLED displays.
