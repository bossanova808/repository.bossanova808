# -*- coding: utf-8 -*-

import sys
from resources.lib import kodi_yoctodisplay

if __name__ == "__main__":
    kodi_yoctodisplay.run(sys.argv)








