
Please see the XBMC Wiki page for full instructions & troubleshooting help:

http://wiki.xbmc.org/index.php?title=XSqueeze
