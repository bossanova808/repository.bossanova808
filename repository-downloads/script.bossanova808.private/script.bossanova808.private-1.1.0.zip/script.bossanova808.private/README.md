Bossanova808 Private
===================================

`script.bossanova808.private`

**Testing only - this add-on may break your system - DON'T INSTALL!**

A private marker add-on for Bossanova808's own Kodi systems. When it is installed and enabled, the Bossanova808 Confluence skins (Omega and Piers) switch on household-specific behaviour, such as custom TV menus for the Adults profiles, fast Adults/Kids profile switching, family birthday backgrounds, and skin utilities.

The skins check for it with `System.AddonIsEnabled(script.bossanova808.private)`, exposed as `$EXP[IsBossanova808]`. Because add-ons are installed per Kodi install rather than per profile, one install covers every profile on a box. Disabling or uninstalling it returns the skins to their standard behaviour.

Per profile, in its settings, it also provides:

- **Profile Switching** - the profile the skin's profile button fast-switches to (with a picker), or empty for a normal log-off.
- **TV Shows menu** - an optional custom TV Shows sub-menu of up to 5 buttons (a label and a target - a library node, playlist or `videodb://` path - each).

A small service copies these into skin strings (which are saved per profile and available as the skin loads), so the skins can show the right menus immediately.

If you have installed this by accident, please uninstall it.
