V1.1
Copy MyWeather.xml to C:\Users\<username>\AppData\Roaming\XBMC\addons\skin.aeonmq5\720p (rename existing one)
Copy the weatherart directory to C:\Users\<username>\AppData\Roaming\XBMC\userdata\addon_data\weather.ozweather

Note: Replace <username> with the username you run XBMC with.

Run XBMC select ozweather as the wetherplugin in settings, set your suburb, radar ID and make sure you turn on "Use Extended Featues (Long Forcast, radar Loop)" and enjoy.

Known issue: The display on the home menu weather does not fully populate.

