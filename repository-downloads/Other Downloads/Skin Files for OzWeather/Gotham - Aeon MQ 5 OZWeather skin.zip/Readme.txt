V1.1

For Helix and future versions:
Copy MyWeather.xml to Kodi\addons\skin.aeonmq5\720p (rename existing MyWeather.xml) 
Copy the weatherart directory to Kodi\userdata\addon_data\weather.ozweather\
For Windows the Kodi directory should be located in %userprofile%\AppData\Roaming


For Gotham and below versions:
Copy MyWeather.xml to XBMC\addons\skin.aeonmq5\720p (rename existing one)
Copy the weatherart directory to XBMC\userdata\addon_data\weather.ozweather\
For Windows the XBMC directory should be located in %userprofile%\AppData\Roaming

Note: Paths are for windows installations, but should be similar for other OS. 
Please refer to the wiki for more info on paths http://kodi.wiki/view/Add-on:Oz_Weather

Run XBMC/Kodi in settings-addons-weather, select ozweather as the wetherplugin, set your suburb, radar ID and make sure you turn on "Use Extended Featues (Long Forcast, radar Loop)" and enjoy.

Known issue: The display on the home menu weather does not fully populate.

