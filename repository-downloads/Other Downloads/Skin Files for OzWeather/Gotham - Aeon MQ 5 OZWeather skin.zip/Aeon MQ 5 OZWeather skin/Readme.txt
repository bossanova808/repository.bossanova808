V1.0
Copy MyWeather.xml to C:\Users\<username>\AppData\Roaming\XBMC (rename existing one)
Copy the weatherart directory to C:\Users\<username>\AppData\Roaming\XBMC\userdata\addon_data\weather.ozweather

Run XBMC select ozweather as the wetherplugin in settings and enjoy.
Note: Replace <username> with the username you run XBMC with.

Known issue: The dislay on the home menu weather does not fully populate.

