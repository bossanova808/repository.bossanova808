# skin.confluence
Private fork of Confluence with a few useful things added.
