# skin.confluence
Private fork of Confluence with a few useful things added.  This is just a holding repo for updates - skin is actually distributed from repository.bossanova808
Reinstate Radio (with PVR) to Menu bar. Enlarged font size for clock, Weather and RSS, increased RSS scrollspeed. (For people who like radio and don't see so well: any more).
